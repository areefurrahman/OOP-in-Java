import java.util.Arrays;

class Worker {
    int workerId;
    String workerName;
    double monthlySalary;
    String[] skills;

    public Worker(int workerId, String workerName, double monthlySalary, String[] skillSet) {
        this.workerId = workerId;
        this.workerName = workerName;
        this.monthlySalary = monthlySalary;
        this.skills = skillSet;
    }

    public double annualSalary() {
        return monthlySalary * 12;
    }

    public double annualSalary(int extraBonus) {
        return monthlySalary * 12 + extraBonus;
    }

    public void showDetails() {
        System.out.println("ID: " + workerId + "\nName: " + workerName + "\nMonthly Salary: $" + monthlySalary +
                "\nYearly Salary without bonus: $" + annualSalary() + "\nSkills: " + Arrays.toString(this.skills));
    }
}

public class Basic_task {
    public static void main(String[] args) {
        String[] skillSet1 = {"Java", "Spring", "SQL"};
        Worker employee1 = new Worker(12345, "John Doe", 5500, skillSet1);
        employee1.showDetails();

        String[] skillSet2 = {"Java", "Spring", "SQL", "C++", "CSS", "HTML", "JavaScript"};
        Worker employee2 = new Worker(67891, "Ali", 99900, skillSet2);
        employee2.showDetails();
    }
}
