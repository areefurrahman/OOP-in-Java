interface IsSensor{
    void initiaLizeSensor();
    void getStatus();
    void readData();
}
interface ItTemperatureSensor extends IsSensor{
    void getTemperature();
    void calibrate();
}
interface IHumiditySensor extends IsSensor{
    void getHumidity();
    void resetSensor();
}
interface IWeatherStation extends ItTemperatureSensor,IHumiditySensor{
    void getClimateData();
    void updateFirmWare();
}
class SmartWeatherStation implements IWeatherStation{
    @Override
    public void initiaLizeSensor() {
        System.out.println("The Sensor is  Initi Lize...");
    }

    @Override
    public void getStatus() {
        System.out.println("Getting Sensor Status...");
    }

    @Override
    public void readData() {
        System.out.println("Read Data From The Sensor");
    }

    @Override
    public void getTemperature() {
        System.out.println("The Sensor Temperature Is High 45 C .....");
    }

    @Override
    public void calibrate() {
        System.out.println("The Calibrate Sensor..");
    }

    @Override
    public void getHumidity() {
        System.out.println("The System Get Humanity..");
    }

    @Override
    public void getClimateData() {
        System.out.println("Getting Climate Data...");
    }

    @Override
    public void resetSensor() {
        System.out.println("System Restarting Successfully");
    }

    @Override
    public void updateFirmWare() {
        System.out.println("System Update SuccessFully...");
    }

}
public class Basic_Practice_Task4 {
    public static void main(String[] args) {
        SmartWeatherStation smartWeatherStation=new SmartWeatherStation();
        smartWeatherStation.getStatus();
        smartWeatherStation.calibrate();
        smartWeatherStation.getClimateData();
        smartWeatherStation.getHumidity();
        smartWeatherStation.readData();
        smartWeatherStation.initiaLizeSensor();
        smartWeatherStation.updateFirmWare();
        smartWeatherStation.getTemperature();
        smartWeatherStation.resetSensor();

    }
}
