interface WiFiEnabled{
    void connectToWiFi(String network);
}
interface RemoteOperable{
    void startRemotely();
}
class SmartRefrigerator implements WiFiEnabled{
    @Override
    public void connectToWiFi(String network) {
        System.out.println("The Wifi Is Connected To "+network);
    }
}
class SmartWashingMachine implements WiFiEnabled,RemoteOperable{
    @Override
    public void connectToWiFi(String network) {
        System.out.println("The Wifi Is Connected To "+network);
    }

    @Override
    public void startRemotely() {
        System.out.println("Wifi Is Connect And startRemotely...");
    }
}
public class Basic_Practice_Task2 {
    public static void main(String[] args) {
        // Original Object using class
        SmartRefrigerator smartRefrigerator=new SmartRefrigerator();
        smartRefrigerator.connectToWiFi("UCP Student Network");

        SmartWashingMachine smartWashingMachine=new SmartWashingMachine();
        smartWashingMachine.connectToWiFi("UCP Staff Network");
        smartWashingMachine.startRemotely();

        // interface reference
        WiFiEnabled wiFiEnabled=new SmartRefrigerator();
        wiFiEnabled.connectToWiFi("UCP It Network");

        RemoteOperable remoteOperable=new SmartWashingMachine();
        remoteOperable.startRemotely();
    }
}
