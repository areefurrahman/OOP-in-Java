interface VideoContent{
    void playVideo();
}
interface Downloadable {
    void downloadResources();
}
class OnlineCourse implements VideoContent,Downloadable{
    @Override
    public void playVideo() {
        System.out.println("Video Is Played ");
    }

    @Override
    public void downloadResources() {
        System.out.println("Video Is Downloading.....");
    }
}
class BasicCourse implements VideoContent{
    @Override
    public void playVideo() {
        System.out.println("Video Is Playing");
    }
}
public class Basic_Practice_Task3 {
    public static void main(String[] args) {
        OnlineCourse onlineCourse=new OnlineCourse();
        onlineCourse.playVideo();
        onlineCourse.downloadResources();
        BasicCourse basicCourse=new BasicCourse();
        basicCourse.playVideo();

    }
}
