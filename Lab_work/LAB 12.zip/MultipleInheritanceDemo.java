abstract class Animal{
    abstract void sound();
    public void sleep()
    {
        System.out.println("The Animal Is Sleeping..");
    }
}
interface pet{
    void play();
    default void eat()
    {
        System.out.println("The Pet Is Eating..");
    }
}
class MyDog extends Animal implements pet{
    void sound()
    {
        System.out.println("The Dog Barks..");
    }

    @Override
    public void play() {
        System.out.println("The Dog Is Playing Fetch");
    }
}
public class MultipleInheritanceDemo {
    public static void main(String[] args) {
        MyDog myDog=new MyDog();
        myDog.play();
        myDog.eat();
        myDog.sound();
        myDog.sleep();
    }
}
