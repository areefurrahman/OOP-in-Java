interface PowerControl {
    void turnOn();
    void turnOff();
}

abstract class SmartDevice {

    public abstract void connect();
}

class SmartLight extends SmartDevice implements PowerControl {
    private boolean isConnected = false;
    private boolean isOn = false;


    @Override
    public void connect() {
        isConnected = true;
        System.out.println("SmartLight connected to the network.");
    }
    @Override
    public void turnOn() {
        if (isConnected) {
            isOn = true;
            System.out.println("SmartLight is turned on.");
        } else {
            System.out.println("Warning: SmartLight is not connected to the network. Please connect it first.");
        }
    }


    @Override
    public void turnOff() {
        if (isConnected && isOn) {
            isOn = false;
            System.out.println("SmartLight is turned off.");
        } else {
            if (!isConnected) {
                System.out.println("Warning: SmartLight is not connected to the network. Please connect it first.");
            } else {
                System.out.println("SmartLight is already off.");
            }
        }
    }
}

public class Scenario {
    public static void main(String[] args) {
        SmartLight smartLight = new SmartLight();

        smartLight.turnOn();


        smartLight.connect();

        smartLight.turnOn();
        smartLight.turnOff();
    }
}
