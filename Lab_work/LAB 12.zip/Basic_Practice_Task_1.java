interface MoveAble{
    void move();
}
interface Floatable{
    void FloatOnWater();
}
class Car implements MoveAble{
    @Override
    public void move() {
        System.out.println("Car Is Moving..");
    }
}
class Boat implements MoveAble,Floatable{
    @Override
    public void move() {
        System.out.println("Boat Is Moving..");
    }

    @Override
    public void FloatOnWater() {
        System.out.println("Boat FLoat On Water");
    }
}
public class Basic_Practice_Task_1 {
    public static void main(String[] args) {
        Car car=new Car();
        car.move();
        Boat boat=new Boat();
        boat.move();
        boat.FloatOnWater();
        MoveAble moveAble=new Car();
        moveAble.move();
        Floatable floatable=new Boat();
        floatable.FloatOnWater();
        MoveAble moveAble1=new Boat();
        moveAble1.move();

    }
}
