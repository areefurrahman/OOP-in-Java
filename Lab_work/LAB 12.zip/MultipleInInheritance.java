interface CanRun{
    void run();
}
interface CanBark{
    void bark();
}
class Dog implements CanRun,CanBark
{
    @Override
    public void run() {
        System.out.println("The Dog Run Quickly");
    }

    @Override
    public void bark() {
        System.out.println("The Dog Bark Loudly");
    }
}
public class MultipleInInheritance {
    public static void main(String[] args) {
        Dog mydog=new Dog();
        mydog.run();
        mydog.bark();
    }
}
