package ToDoList;

public class ToDoListMain {
    public static void main(String[] args) {
        new MainFrame();

    }

}
