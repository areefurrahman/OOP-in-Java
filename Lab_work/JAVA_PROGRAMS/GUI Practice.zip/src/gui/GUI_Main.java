package gui;

import javax.swing.*;
import java.awt.*;

public class GUI_Main {
    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setVisible(true);
        frame.setTitle("Inventory Management System");

//        frame.setSize(500, 300);
        frame.setBounds(500,300,900,700);
        frame.setMinimumSize(new Dimension(400,200));

        // icon change
        ImageIcon icon = new ImageIcon("icon.png");
        frame.setIconImage(icon.getImage());
        frame.setResizable(false);
//      Set frame BG colors
        frame.getContentPane().setBackground(Color.getHSBColor(248,249,252));

//      Label
        JLabel label = new JLabel();
        label.setText("Student Name");
        frame.add(label);
        label.setIcon(icon);


        label.setHorizontalTextPosition(JLabel.CENTER);
        label.setVerticalTextPosition(JLabel.TOP);

        label.setForeground(new Color(0xFF4A4A));
//      Set Font
        label.setFont(new Font("Metropolis", Font.BOLD,35));

        label.setVerticalAlignment(JLabel.CENTER);
        label.setHorizontalAlignment(JLabel.CENTER);
        label.setIconTextGap(34);


        frame.pack();

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }
}
