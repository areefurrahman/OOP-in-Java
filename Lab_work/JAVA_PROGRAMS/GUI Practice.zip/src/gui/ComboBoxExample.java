package gui;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ComboBoxExample {
    public static void main(String[] args) {
        // Create the frame
        JFrame frame = new JFrame("ComboBox Example");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200);

        // Create a panel
        JPanel panel = new JPanel();

        // Create a label
        JLabel label = new JLabel("Select an item:");

        // Create an array of items for the combo box
        String[] items = {"Option 1", "Option 2", "Option 3", "Option 4"};

        // Create a combo box with the items
        JComboBox<String> comboBox = new JComboBox<>(items);


        // Set the default selected item (optional)
        comboBox.setSelectedIndex(0); // Selects the first item by default

        // Add an action listener to the combo box
        comboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedItem = (String) comboBox.getSelectedItem();
                JOptionPane.showMessageDialog(frame, "You selected: " + selectedItem);
            }
        });

        // Add components to the panel
        panel.add(label);
        panel.add(comboBox);

        // Add the panel to the frame
        frame.add(panel);
        frame.setVisible(true);
    }
}