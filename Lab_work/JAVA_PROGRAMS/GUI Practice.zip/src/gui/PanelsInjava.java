package gui;

import javax.swing.*;
import java.awt.*;

public class PanelsInjava {
    public static void main(String[] args) {

        JPanel topleftpanel = new JPanel();
        topleftpanel.setBackground(new Color(0xE6935C));
        topleftpanel.setBounds(0,0,200,200);

        JPanel topRightpanel = new JPanel();
        topRightpanel.setBackground(new Color(0x65E65C));
        topRightpanel.setBounds(200,0,200,200);

        JPanel Bottomtpanel = new JPanel();
        Bottomtpanel.setBackground(new Color(0x570DD6));
        Bottomtpanel.setBounds(0,200,400,200);



        JFrame frame  = new JFrame();
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setTitle("Panels");
        frame.setSize(500,500);
        frame.setLayout(null);

        frame.add(topleftpanel);
        frame.add(topRightpanel);
        frame.add(Bottomtpanel);

    }
}
