package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

class textInput extends JFrame{

    textInput(){


        JLabel enterdName = new JLabel();

        JPanel outputName = new JPanel();
        outputName.setBounds(0,100,300,100);
        outputName.setBackground(new Color(0x17BD69));
        outputName.add(enterdName);


        JTextField nameInput = new JTextField(10);
        nameInput.setBorder(BorderFactory.createRaisedBevelBorder());

        nameInput.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameInput.getText();
                enterdName.setText("Entered name is: " + name);
                nameInput.setEnabled(false);
            }
        });


        JPanel nameInputPanel = new JPanel();
        nameInputPanel.setBounds(0,0,300,100);
        nameInputPanel.setBackground(new Color(0x2FCDCD));
        nameInputPanel.add(new JLabel("Enter your Name: "));
        nameInputPanel.add(nameInput);





        this.setBounds(0,0,300,500);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(null);
        this.add(nameInputPanel);
        this.add(outputName);

        this.setVisible(true);
    }

}

public class textfeildPractice{
    public static void main(String[] args) {

        new textInput();
    }

}
