package com.Inventory;

import java.io.*;
import java.util.ArrayList;

class Product {
    String productID;
    String name;
    String category;
    double unitPrice;
    int quantity;
    int reorderLevel;
    String supplierID;

    public Product() {
        this.productID = "";
        this.name = "";
        this.category = "";
        this.unitPrice = 0.0;
        this.quantity = 0;
        this.reorderLevel = 0;
        this.supplierID = "";
    }

    public Product(String productID, String name, String category, double unitPrice, int quantity, int reorderLevel, String supplierID) {
        this.productID = productID;
        this.name = name;
        this.category = category;
        this.unitPrice = unitPrice;
        this.quantity = quantity;
        this.reorderLevel = reorderLevel;
        this.supplierID = supplierID;

    }


    public void decreaseQuantityInFile(String productID) {
        ArrayList<String> lines = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("Products.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                if (data[0].equals(productID)) {
                    int quantity = Integer.parseInt(data[5]) - 1;
                    data[5] = String.valueOf(quantity);
                    line = String.join(",", data);
                }
                lines.add(line);
            }
        } catch (IOException e) {
            System.out.println("Error reading from file: " + e.getMessage());
        }
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("Products.txt"))) {
            for (String line : lines) {
                writer.write(line);
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }
    }

    public void increaseQuantityInFile(String productID) {
        ArrayList<String> lines = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("Products.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                if (data[0].equals(productID)) {
                    int quantity = Integer.parseInt(data[5]) + 1;
                    data[5] = String.valueOf(quantity);
                    line = String.join(",", data);
                }
                lines.add(line);
            }
        } catch (IOException e) {
            System.out.println("Error reading from file: " + e.getMessage());
        }
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("Products.txt"))) {
            for (String line : lines) {
                writer.write(line);
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }
    }


    public void displayDetails() {
        System.out.println("ProductID: " + productID);
        System.out.println("Name: " + name);
        System.out.println("Category: " + quantity);
        System.out.println("Unit Price: " + unitPrice);
        System.out.println("Quantity: " + quantity);
        System.out.println("Reorder Level: " + reorderLevel);
        System.out.println("Supplier ID : " + supplierID);
    }

}
