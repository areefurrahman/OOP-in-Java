package com.Inventory;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;

public class ViewSuppliersFrame extends JFrame {

    private Inventory inventory;

    public ViewSuppliersFrame(Admin employee) {
        this.inventory = employee.inventory;

        // Frame properties
        setTitle("View Suppliers");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null); // Absolute positioning
        setResizable(false);

        // Dark theme colors
        Color backgroundColor = new Color(40, 40, 40);
        Color foregroundColor = Color.WHITE;
        Color buttonColor = new Color(60, 60, 60);

        getContentPane().setBackground(backgroundColor);

        // Title Label
        JLabel titleLabel = new JLabel("Supplier List", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(foregroundColor);
        titleLabel.setBounds(150, 20, 300, 40);
        add(titleLabel);

        // Table to display suppliers
        String[] columnNames = {"Supplier ID", "Name", "Contact", "Address"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
        JTable supplierTable = new JTable(tableModel);

        // Table properties
        supplierTable.setBackground(buttonColor);
        supplierTable.setForeground(foregroundColor);
        supplierTable.setFont(new Font("Arial", Font.PLAIN, 14));
        supplierTable.setRowHeight(25);
        supplierTable.getTableHeader().setBackground(backgroundColor);
        supplierTable.getTableHeader().setForeground(foregroundColor);
        supplierTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));

        // Scroll pane for the table
        JScrollPane scrollPane = new JScrollPane(supplierTable);
        scrollPane.setBounds(50, 80, 500, 200);
        add(scrollPane);

        // Load data into the table
        ArrayList<String> supplierData = inventory.readAllSuppliersFromFile();
        for (String supplierLine : supplierData) {
            String[] supplierDetails = supplierLine.split(","); // Assuming data in file is comma-separated
            tableModel.addRow(supplierDetails);
        }

        // Close button
        JButton closeButton = new JButton("CLOSE");
        closeButton.setBounds(250, 300, 100, 30);
        closeButton.setBackground(buttonColor);
        closeButton.setForeground(foregroundColor);
        closeButton.setFocusPainted(false);
        closeButton.addActionListener(e -> dispose());
        add(closeButton);

        // Center the frame on the screen
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
