package com.Inventory;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

class Employee extends User {
    Scanner input = new Scanner(System.in);
    ArrayList<Order> orders;
    ArrayList<Product> products;

    public Employee(String userID, String name, String email, String password, String role) {
        super(userID, name, email, password, role);
        orders = new ArrayList<>();
        products = new ArrayList<>();
    }

    public Employee() {
        super();
    }


    public void Login() {
        System.out.println("Enter ID: ");
        String id = input.nextLine();
        System.out.println("Enter Password: ");
        String password = input.nextLine();
        if (authenticate(id, password)) {
            System.out.println("Logged in Successfully!");
        } else {
            System.out.println("Error: ID or Password doesn't matched!");
        }
    }

    //function authenticate employee
    private boolean authenticate(String id, String password) {
        // checking if the employee this id and password is present in the file or not:
        try (BufferedReader reader = new BufferedReader(new FileReader("Employees.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                if (data[0].equals(id) && data[3].equals(password)) {
                    return true;
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
        return false;
    }


    public void addProduct(String productID, String name, String category, double unitPrice, int quantity, int reorderLevel, String supplierID) {
        Product product = new Product(productID, name, category, unitPrice, quantity, reorderLevel, supplierID);
        products.add(product);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("products.txt", true))) {
            String data = product.productID + "," + product.name + "," + product.category + "," + product.unitPrice + "," + product.quantity + "," + product.reorderLevel + "," + product.supplierID;
            writer.newLine();
            writer.write(data);
            System.out.println("Product added successfully!");
        } catch (IOException e) {
            System.out.println("Error adding product: " + e.getMessage());
        }
    }

    public boolean removeProduct(String productID) {
        try (BufferedReader reader = new BufferedReader(new FileReader("Products.txt"))) {
            String line;
            StringBuilder updatedData = new StringBuilder();
            boolean productFound = false;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                if (!data[0].equals(productID)) {
                    updatedData.append(line).append("\n");
                } else {
                    productFound = true;
                }
            }
            if (productFound) {
                try (BufferedWriter writer = new BufferedWriter(new FileWriter("Products.txt"))) {
                    writer.write(updatedData.toString());
                    System.out.println("Product removed successfully!");
                } catch (IOException e) {
                    System.out.println("Error removing product: " + e.getMessage());
                }
            } else {
                System.out.println("Product not found!");
            }
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
        return false;
    }


    public void addOrder(String orderID, String orderDate, String status, String productIDs, String supplierID) throws IOException {
        Order order = new Order(orderDate, status);
        orders.add(order);
        BufferedWriter writer = new BufferedWriter(new FileWriter("Orders.txt", true));
        String data = order.orderID + "," + order.orderDate + "," + order.status;
        writer.newLine();
        writer.write(data);
        System.out.println("Order added successfully!");

    }
    public void addOrder(String orderDate, String orderStatus, ArrayList<ArrayList<String>> productsInOrder) throws IOException {
        Order order = new Order(orderDate, orderStatus);
        orders.add(order);
        BufferedWriter writer = new BufferedWriter(new FileWriter("Orders.txt", true));
        String data = order.orderID + "," + order.orderDate + "," + order.status;
        writer.newLine();
        writer.write(data);
    }

    public boolean removeOrder(String orderID) {
        try (BufferedReader reader = new BufferedReader(new FileReader("Orders.txt"))) {
            String line;
            StringBuilder updatedData = new StringBuilder();
            boolean orderFound = false;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                if (!data[0].equals(orderID)) {
                    updatedData.append(line).append("\n");
                } else {
                    orderFound = true;
                }
            }
            if (orderFound) {
                try (BufferedWriter writer = new BufferedWriter(new FileWriter("Orders.txt"))) {
                    writer.write(updatedData.toString());
                    System.out.println("Order removed successfully!");
                } catch (IOException e) {
                    System.out.println("Error removing order: " + e.getMessage());
                }
            } else {
                System.out.println("Order not found!");
            }
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
        return false;
    }

    Inventory inventory = new Inventory();

    public void viewProducts() {
        ArrayList<String> employees = inventory.readAllProductsFromFile();
    }

    public void viewOrders() {
        ArrayList<String> employees = inventory.displayAllOrdersFromFile();
    }

    @Override
    public void displayDetails() {
        System.out.println("Employee User ID: " + userID);
        System.out.println("Name: " + name);
        System.out.println("Email: " + email);
        System.out.println("Password: " + password);
        System.out.println("Role: " + role);
    }
    public static boolean validateEmployeeCredentials(String userID, String password) {
        try (BufferedReader reader = new BufferedReader(new FileReader("Employees.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length >= 4) { // Ensure there are at least 4 elements (ID, name, email, password)
                    String storedUserID = data[0].trim();
                    String storedPassword = data[3].trim();

                    if (storedUserID.equals(userID) && storedPassword.equals(password)) {
                        return true; // Credentials match
                    }
                } else {
                    System.err.println("Invalid line format in Employees.txt: " + line);
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading Employees.txt: " + e.getMessage());

        }
        return false; // Credentials not found
    }

}