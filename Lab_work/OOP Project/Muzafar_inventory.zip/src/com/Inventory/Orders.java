package com.Inventory;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

class Order {
    int orderID = 0;
    ArrayList<Product> productList;
    String orderDate;
    String status;

    public Order(String orderDate, String status) {
        orderID++;
        this.productList = new ArrayList<>();
        this.orderDate = orderDate;
        this.status = status;
    }

    public void addProductInOrder(Product product) {
        productList.add(product);
        System.out.println("Product added to order " + orderID);
        product.quantity--;
        product.increaseQuantityInFile(product.productID);
    }

    public void removeProductFromOrder(Product product) {
        productList.remove(product);
        System.out.println("Product added to order " + orderID);
        product.quantity++;
        product.decreaseQuantityInFile(product.productID);
    }

    public void updateOrderStatus(String status) {
        this.status = status;
        System.out.println("Order status updated to " + status);
    }


    public void getOrderDetails() {
        System.out.println("Order ID: " + orderID);
        System.out.println("Order Date: " + orderDate);
        System.out.println("Status: " + status);
        System.out.println("Product List:");
        for (Product product : productList) {
            product.displayDetails();
        }
    }
}