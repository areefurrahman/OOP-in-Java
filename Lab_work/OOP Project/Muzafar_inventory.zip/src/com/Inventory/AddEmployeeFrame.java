package com.Inventory;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddEmployeeFrame extends JFrame {

    public AddEmployeeFrame(Admin admin) {
        // Set up the frame
        setTitle("Add New Employee");
        setSize(400, 390);
        setLayout(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Dark theme colors
        Color backgroundColor = new Color(40, 40, 40);
        Color foregroundColor = Color.WHITE;
        Color buttonColor = new Color(60, 60, 60);

        getContentPane().setBackground(backgroundColor);

        // Employee details fields
        JTextField nameField = new JTextField();
        JTextField idField = new JTextField();
        JTextField positionField = new JTextField();
        JTextField emailField = new JTextField();
        JTextField passwordField= new JTextField();

        // Labels
        JLabel nameLabel = new JLabel("Name:");
        JLabel idLabel = new JLabel("Employee ID:");
        JLabel positionLabel = new JLabel("Position:");
        JLabel emailLabel = new JLabel("Email:");
        JLabel PasswordLabel = new JLabel("Password:");

        // Set bounds for labels and fields
        nameLabel.setBounds(50, 50, 100, 25);
        nameLabel.setForeground(foregroundColor);
        idLabel.setBounds(50, 90, 100, 25);
        idLabel.setForeground(foregroundColor);
        positionLabel.setBounds(50, 130, 100, 25);
        positionLabel.setForeground(foregroundColor);
        emailLabel.setBounds(50, 170, 100, 25);
        emailLabel.setForeground(foregroundColor);
        PasswordLabel.setBounds(50, 210, 100, 25);
        PasswordLabel.setForeground(foregroundColor);

        nameField.setBounds(160, 50, 200, 25);
        idField.setBounds(160, 90, 200, 25);
        positionField.setBounds(160, 130, 200, 25);
        emailField.setBounds(160, 170, 200, 25);
        passwordField.setBounds(160, 210, 200, 25);

        // Buttons
        JButton addButton = new JButton("Add Employee");
        addButton.setBounds(100, 260, 200, 30);
        addButton.setBackground(buttonColor);
        addButton.setForeground(foregroundColor);

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Logic to add the employee (mock example)
                String name = nameField.getText();
                String id = idField.getText();
                String position = positionField.getText();
                String email = emailField.getText();
                String password = passwordField.getText();

                if(name.isEmpty()||id.isEmpty()||position.isEmpty()||email.isEmpty()||password.isEmpty()){
                    JOptionPane.showMessageDialog(null, "Invalid Input: " + name, "Error", JOptionPane.ERROR_MESSAGE);
                    nameField.setText("");
                    idField.setText("");
                    positionField.setText("");
                    emailField.setText("");
                    passwordField.setText("");
                }
                else {
                    Admin.addEmployee(id,name,email,password,position);
                    JOptionPane.showMessageDialog(null, "Employee Added: " + name, "Success", JOptionPane.INFORMATION_MESSAGE);

                    // Clear fields after adding
                    nameField.setText("");
                    idField.setText("");
                    positionField.setText("");
                    emailField.setText("");
                    passwordField.setText("");
                }
            }
        });

        // Add components to frame
        add(nameLabel);
        add(idLabel);
        add(positionLabel);
        add(emailLabel);
        add(nameField);
        add(idField);
        add(positionField);
        add(emailField);
        add(PasswordLabel);
        add(passwordField);
        add(addButton);

        // Visible frame
        setLocationRelativeTo(null);
        setVisible(true);
    }

}
