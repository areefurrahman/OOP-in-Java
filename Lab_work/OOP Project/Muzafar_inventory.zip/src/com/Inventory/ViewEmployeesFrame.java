package com.Inventory;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;

public class ViewEmployeesFrame extends JFrame {

    private Inventory inventory;

    public ViewEmployeesFrame(Admin employee) {
        this.inventory = employee.inventory;

        // Frame properties
        setTitle("View Employees");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null); // Absolute positioning
        setResizable(false);

        // Dark theme colors
        Color backgroundColor = new Color(40, 40, 40);
        Color foregroundColor = Color.WHITE;
        Color buttonColor = new Color(60, 60, 60);

        getContentPane().setBackground(backgroundColor);

        // Title Label
        JLabel titleLabel = new JLabel("Employee List", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(foregroundColor);
        titleLabel.setBounds(150, 20, 300, 40);
        add(titleLabel);

        // Table to display employees
        String[] columnNames = {"Employee ID", "Name", "Email", "Password"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
        JTable employeeTable = new JTable(tableModel);

        // Table properties
        employeeTable.setBackground(buttonColor);
        employeeTable.setForeground(foregroundColor);
        employeeTable.setFont(new Font("Arial", Font.PLAIN, 14));
        employeeTable.setRowHeight(25);
        employeeTable.getTableHeader().setBackground(backgroundColor);
        employeeTable.getTableHeader().setForeground(foregroundColor);
        employeeTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));

        // Scroll pane for the table
        JScrollPane scrollPane = new JScrollPane(employeeTable);
        scrollPane.setBounds(50, 80, 500, 200);
        add(scrollPane);

        // Load data into the table
        ArrayList<String> employeeData = inventory.readAllEmployeesFromFile();
        for (String employeeLine : employeeData) {
            String[] employeeDetails = employeeLine.split(","); // Assuming data in file is comma-separated
            tableModel.addRow(employeeDetails);
        }

        // Close button
        JButton closeButton = new JButton("CLOSE");
        closeButton.setBounds(250, 300, 100, 30);
        closeButton.setBackground(buttonColor);
        closeButton.setForeground(foregroundColor);
        closeButton.setFocusPainted(false);
        closeButton.addActionListener(e -> dispose());
        add(closeButton);

        // Center the frame on the screen
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
