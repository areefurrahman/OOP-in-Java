package com.Inventory;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class EmployeeDashboard extends JFrame {
    private Employee employee;
    private AbstractButton order;

    public EmployeeDashboard(Employee employee) {
        this.employee = employee;

        // Set title and size
        setTitle("Employee Dashboard - " + employee.getName());
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLayout(new BorderLayout());

        // Dark theme colors
        Color backgroundColor = new Color(40, 40, 40);
        Color foregroundColor = Color.WHITE;
        Color buttonColor = new Color(60, 60, 60);

        getContentPane().setBackground(backgroundColor);

        // Top Panel: User Info
        JPanel userInfoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        userInfoPanel.setBackground(backgroundColor);

        JLabel userInfoLabel = new JLabel("Welcome, " + employee.getName() + " (" + employee.getUserID() + ")");
        userInfoLabel.setForeground(foregroundColor);
        userInfoLabel.setFont(new Font("Arial", Font.BOLD, 16));
        userInfoPanel.add(userInfoLabel);

        add(userInfoPanel, BorderLayout.NORTH);

        // Center Panel: Buttons
        JPanel centerPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        centerPanel.setBackground(backgroundColor);

        JButton addProductButton = createStyledButton("Add Product", e -> new AddProductFrame(employee));
        centerPanel.add(addProductButton);

        JButton removeProductButton = createStyledButton("Remove Product", e -> {
            String productID = JOptionPane.showInputDialog(this, "Enter Product ID to remove:", "Remove Product", JOptionPane.QUESTION_MESSAGE);
            if (productID != null) {
                boolean success = employee.removeProduct(productID);
                if (success) {
                    JOptionPane.showMessageDialog(this, "Product removed successfully.");
                } else {
                    JOptionPane.showMessageDialog(this, "Product ID not found!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        centerPanel.add(removeProductButton);

        JButton viewProductsButton = createStyledButton("View Products", e -> new ViewProductsFrame(employee));
        centerPanel.add(viewProductsButton);

        JButton addOrderButton = createStyledButton("Add Order", e -> new AddOrderFrame(employee));
        centerPanel.add(addOrderButton);


        JButton removeOrderButton = createStyledButton("Remove Order", e -> {
            String orderID = JOptionPane.showInputDialog(this, "Enter Order ID to remove:", "Remove Order", JOptionPane.QUESTION_MESSAGE);
            if (orderID != null) {
                boolean success = employee.removeOrder(orderID);
                if (success) {
                    JOptionPane.showMessageDialog(this, "Order removed successfully.");
                } else {
                    JOptionPane.showMessageDialog(this, "Order ID not found!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        centerPanel.add(removeOrderButton);

        JButton viewOrdersButton = createStyledButton("View Orders", e -> new ViewOrdersFrame(employee));
        centerPanel.add(viewOrdersButton);

        add(centerPanel, BorderLayout.CENTER);

        // Bottom Panel: Logout
        JPanel logoutPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        logoutPanel.setBackground(backgroundColor);

        JButton logoutButton = createStyledButton("Logout", e -> {
            dispose();
            System.exit(0);
        });
        logoutPanel.add(logoutButton);

        add(logoutPanel, BorderLayout.SOUTH);

        // Center the frame on the screen
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private JButton createStyledButton(String text, ActionListener listener) {
        Color buttonColor = new Color(60, 60, 60);
        Color foregroundColor = Color.WHITE;

        JButton button = new JButton(text);
        button.addActionListener(listener);
        button.setBackground(buttonColor);
        button.setForeground(foregroundColor);
        button.setFocusPainted(false);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY));
        return button;
    }

    public void refreshOrderTable() {
        // Clear the current table content
        DefaultTableModel tableModel = (DefaultTableModel) order.getModel();
        tableModel.setRowCount(0);

        // Read all orders from the file
        ArrayList<String> ordersData = employee.inventory.displayAllOrdersFromFile();

        // Populate the table with new data
        for (String orderLine : ordersData) {
            String[] orderDetails = orderLine.split(","); // Assuming data in file is comma-separated
            tableModel.addRow(orderDetails);
        }
    }

    // Example Frame Classes with Dark Theme (AddProductFrame, ViewProductsFrame, etc.)
    private class AddProductFrame extends JFrame {
        public AddProductFrame(Employee employee) {
            setTitle("Add Product");
            setSize(400, 350);
            setLayout(new GridLayout(8, 2, 10, 10));
            getContentPane().setBackground(new Color(40, 40, 40));

            Color buttonColor = new Color(60, 60, 60);
            Color foregroundColor = Color.WHITE;

            // Text fields
            JTextField idField = new JTextField();
            JTextField nameField = new JTextField();
            JTextField categoryField = new JTextField();
            JTextField unitPriceField = new JTextField();
            JTextField quantityField = new JTextField();
            JTextField reorderLevelField = new JTextField();
            JTextField supplierIDField = new JTextField();

// Labels
            JLabel[] labels = {
                    new JLabel("ID:"), new JLabel("Name:"), new JLabel("Category:"),
                    new JLabel("Unit Price:"), new JLabel("Quantity:"),
                    new JLabel("Reorder Level:"), new JLabel("Supplier ID:")
            };

// Corresponding text fields
            JTextField[] fields = {
                    idField, nameField, categoryField, unitPriceField,
                    quantityField, reorderLevelField, supplierIDField
            };

// Layout parameters
            int xLabel = 50, yLabel = 50, labelWidth = 100, labelHeight = 25;
            int xField = 160, yField = 50, fieldWidth = 200, fieldHeight = 25;
            int gap = 40; // Gap between rows

// Add labels and fields in pairs
            for (int i = 0; i < labels.length; i++) {
                // Configure and add label
                JLabel label = labels[i];
                label.setForeground(foregroundColor);
                label.setBounds(xLabel, yLabel, labelWidth, labelHeight);
                label.setFont(new Font("Arial", Font.BOLD, 14)); // Optional font customization
                add(label);

                // Configure and add field
                JTextField field = fields[i];
                field.setBackground(buttonColor);
                field.setForeground(foregroundColor);
                field.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY));
                field.setFont(new Font("Arial", Font.PLAIN, 14)); // Optional font customization
                field.setBounds(xField, yField, fieldWidth, fieldHeight);
                field.setToolTipText("Enter " + label.getText().replace(":", "")); // Add tooltip
                add(field);

                // Increment y positions for next row
                yLabel += gap;
                yField += gap;
            }


            // Add Button
            JButton addButton = createStyledButton("Add", e -> {
                try {
                    String id = idField.getText();
                    String name = nameField.getText();
                    String category = categoryField.getText();
                    double unitPrice = Double.parseDouble(unitPriceField.getText());
                    int quantity = Integer.parseInt(quantityField.getText());
                    int reorderLevel = Integer.parseInt(reorderLevelField.getText());
                    String supplierID = supplierIDField.getText();

                    employee.addProduct(id, name, category, unitPrice, quantity, reorderLevel, supplierID);
                    JOptionPane.showMessageDialog(this, "Product added successfully!");
                    dispose();
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "Invalid input. Please enter valid numbers for price, quantity, and reorder level.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            });

            add(addButton);

            setLocationRelativeTo(null);
            setVisible(true);
        }
    }
}
