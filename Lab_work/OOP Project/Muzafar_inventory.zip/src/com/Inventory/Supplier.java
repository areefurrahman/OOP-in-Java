package com.Inventory;

import java.util.ArrayList;

public class Supplier {
    private String supplierID;
    private String name;
    private String email;
    private String phone;
    private String address;
    private String productCategories;

    public Supplier(String supplierID, String name, String address, String phone, String email, String productCategories) {
        this.supplierID = supplierID;
        this.productCategories = productCategories;
        this.address = address;
        this.phone = phone;
        this.email = email;
        this.name = name;
    }

    public String getSupplierID() {
        return supplierID;
    }

    public void setSupplierID(String supplierID) {
        this.supplierID = supplierID;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getProductCategories() {
        return productCategories;
    }

    public void setProductCategories(String productCategories) {
        this.productCategories = productCategories;
    }

    public void displayDetails() {
        System.out.println("Supplier ID: " + supplierID);
        System.out.println("Name: " + name);
        System.out.println("Email: " + email);
        System.out.println("Phone: " + phone);
        System.out.println("Address: " + address);
        System.out.println("Product Categories: " + productCategories);
        System.out.println("Products lists: ");
    }
}
