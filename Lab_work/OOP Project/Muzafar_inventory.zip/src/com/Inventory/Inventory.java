package com.Inventory;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Inventory {
    ArrayList<Product> products;
    ArrayList<Supplier> suppliers;
    ArrayList<Employee> employees;

    public Inventory() {
        this.products = new ArrayList<>();
        this.suppliers = new ArrayList<>();
        this.employees = new ArrayList<>();
    }

    public void displayProducts() {
        for (Product product : products) {
            product.displayDetails();
            System.out.println("-----------------------------------------------------");
        }
    }

    public void displaySuppliers() {
        for (Supplier supplier : suppliers) {
            supplier.displayDetails();
            System.out.println("-----------------------------------------------------");
        }
    }

    public void displayEmployees() {
        for (Employee employee : employees) {
            employee.displayDetails();
            System.out.println("-----------------------------------------------------");
        }
    }

    // function to display all products from file:
    public ArrayList<String> readAllProductsFromFile() {
        ArrayList<String> products = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("Products.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                products.add(line);
            }
        } catch (IOException e) {
            System.out.println("Error reading from file: " + e.getMessage());
        }
        return products;
    }


    // function to display all orders from file:
    public ArrayList<String> displayAllEmployeesFromFile() {
        ArrayList<String> employees = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("Employees.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                employees.add(line);
            }
        } catch (IOException e) {
            System.out.println("Error reading from file: " + e.getMessage());
        }
        return employees;
    }



    //read all employees from File:
    public ArrayList<String> readAllEmployeesFromFile() {
        ArrayList<String> employees = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("Employees.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                employees.add(line);
            }
        } catch (IOException e) {
            System.out.println("Error reading from file: " + e.getMessage());
        }
        return employees;
    }



    public ArrayList<String> readAllSuppliersFromFile() {
        ArrayList<String> suppliers = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("Suppliers.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                suppliers.add(line);
            }
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
        return suppliers;
    }

    //read all orders from File:
    public ArrayList<String> displayAllOrdersFromFile() {
        ArrayList<String> orders = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("Orders.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                orders.add(line);
            }
        } catch (IOException e) {
            System.out.println("Error reading from file: " + e.getMessage());
        }
        return orders;
    }
}