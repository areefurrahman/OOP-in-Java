package com.Inventory;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginPage extends JFrame {
    // Components
    private JLabel titleLabel;
    private JLabel usernameLabel;
    private JTextField usernameField;
    private JLabel passwordLabel;
    private JPasswordField passwordField;
    private JComboBox<String> roleComboBox;
    private JButton loginButton;
    private JButton clearButton;

    // Constructor
    public LoginPage() {
        // Set title
        setTitle("Login");
        // Set size
        setSize(400, 350);
        // Set layout
        setLayout(null); // Using absolute layout for precise positioning
        // Set default close operation
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // Set resizable to false
        setResizable(false);

        // Set dark theme colors
        Color backgroundColor = new Color(40, 40, 40); // Dark gray
        Color foregroundColor = Color.WHITE; // White text
        Color buttonColor = new Color(60, 60, 60); // Slightly lighter dark gray

        // Set background color for the frame
        getContentPane().setBackground(backgroundColor);

        // Initialize components
        titleLabel = new JLabel("INVENTORY SYSTEM", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(foregroundColor);
        titleLabel.setBounds(50, 20, 300, 40);

        usernameLabel = new JLabel("Username:");
        usernameLabel.setForeground(foregroundColor);
        usernameLabel.setBounds(50, 80, 100, 25);

        usernameField = new JTextField();
        usernameField.setBounds(150, 80, 200, 25);
        usernameField.setBackground(buttonColor);
        usernameField.setForeground(foregroundColor);
        usernameField.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY));

        passwordLabel = new JLabel("Password:");
        passwordLabel.setForeground(foregroundColor);
        passwordLabel.setBounds(50, 130, 100, 25);

        passwordField = new JPasswordField();
        passwordField.setBounds(150, 130, 200, 25);
        passwordField.setBackground(buttonColor);
        passwordField.setForeground(foregroundColor);
        passwordField.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY));

        roleComboBox = new JComboBox<>(new String[]{"Administrator","Employee"});
        roleComboBox.setBounds(150, 180, 200, 25);
        roleComboBox.setBackground(buttonColor);
        roleComboBox.setForeground(foregroundColor);
        roleComboBox.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY));

        loginButton = new JButton("LOGIN");
        loginButton.setBounds(100, 240, 90, 30);
        loginButton.setBackground(buttonColor);
        loginButton.setForeground(foregroundColor);
        loginButton.setFocusPainted(false);
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String role = (String) roleComboBox.getSelectedItem();
                String userID = usernameField.getText().trim();
                String password = new String(passwordField.getPassword()).trim();

                if (userID.isEmpty() || password.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please enter both User ID and Password!", "Login Failed", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                if ("Administrator".equals(role) && "Admin1".equals(userID) && "Admin1".equals(password)) {
                   Admin admin=new Admin();
                   AdminDashboard adminDashboard=new AdminDashboard(admin);

                }
                else if ("Employee".equals(role)) {
                    if (Employee.validateEmployeeCredentials(userID, password)) {
                        Employee employee=new Employee();
                        EmployeeDashboard employeeDashboard=new EmployeeDashboard(employee);
                    } else {
                        JOptionPane.showMessageDialog(null, "Invalid Employee credentials! Please check your User ID and Password.", "Login Failed", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid credentials! Please try again.", "Login Failed", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        clearButton = new JButton("CLEAR");
        clearButton.setBounds(210, 240, 90, 30);
        clearButton.setBackground(buttonColor);
        clearButton.setForeground(foregroundColor);
        clearButton.setFocusPainted(false); // Removes focus border
        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Clear username and password fields
                usernameField.setText("");
                passwordField.setText("");
            }
        });

        // Add components to frame
        add(titleLabel);
        add(usernameLabel);
        add(usernameField);
        add(passwordLabel);
        add(passwordField);
        add(roleComboBox);
        add(loginButton);
        add(clearButton);

        // Center the frame on the screen
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        LoginPage LG = new LoginPage();
    }
}