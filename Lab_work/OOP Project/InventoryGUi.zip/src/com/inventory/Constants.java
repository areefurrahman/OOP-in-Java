package com.inventory;

import java.awt.*;

public class Constants {
    public static final Color DARK_BACKGROUND = new Color(40, 40, 40);
    public static final Color LIGHT_BACKGROUND = new Color(60, 60, 60);
    public static final Color TEXT_COLOR = Color.WHITE;
    public static final Font HEADER_FONT = new Font("Segoe UI", Font.BOLD, 24);
    public static final Font BUTTON_FONT = new Font("Segoe UI", Font.BOLD, 14);
}