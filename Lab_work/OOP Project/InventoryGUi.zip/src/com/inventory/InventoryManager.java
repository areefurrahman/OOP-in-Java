package com.inventory;

import javax.swing.*;
import java.util.ArrayList;

public class InventoryManager {
    public void addProduct(JFrame parent) {
        ArrayList<String> productData = new ArrayList<>();
        String[] prompts = {"Product ID", "Product Name", "Category",
                "Unit Price", "Quantity", "Reorder Level", "Supplier ID"};

        for (String prompt : prompts) {
            String input = JOptionPane.showInputDialog(parent, "Enter " + prompt + ":");
            if (input == null || input.trim().isEmpty()) return;
            productData.add(input);
        }

        try {
            FileManager.appendToFile("Products.txt", String.join(",", productData));
            JOptionPane.showMessageDialog(parent, "Product added successfully!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(parent,
                    "Error adding product: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    public void removeProduct(JFrame parent) {
        try {
            ArrayList<String[]> productData = FileManager.readFileData("Products.txt");

            if (productData.isEmpty()) {
                JOptionPane.showMessageDialog(parent,
                        "No products available to remove.",
                        "Remove Product",
                        JOptionPane.WARNING_MESSAGE
                );
                return;
            }

            JPanel panel = new JPanel(new java.awt.BorderLayout());
            DefaultListModel<String> listModel = new DefaultListModel<>();

            for (String[] product : productData) {
                listModel.addElement(product[0] + " - " + product[1]);
            }

            JList<String> productList = new JList<>(listModel);
            productList.setBackground(Constants.LIGHT_BACKGROUND);
            productList.setForeground(Constants.TEXT_COLOR);
            productList.setSelectionBackground(new java.awt.Color(100, 100, 100));

            panel.add(new JScrollPane(productList), java.awt.BorderLayout.CENTER);

            int result = JOptionPane.showConfirmDialog(
                    parent,
                    panel,
                    "Select Product to Remove",
                    JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.PLAIN_MESSAGE
            );

            if (result == JOptionPane.OK_OPTION) {
                String selectedProduct = productList.getSelectedValue();
                if (selectedProduct != null) {
                    String productIdToRemove = selectedProduct.split(" - ")[0];

                    productData.removeIf(product -> product[0].equals(productIdToRemove));

                    FileManager.writeFileData("Products.txt", productData);

                    JOptionPane.showMessageDialog(parent,
                            "Product removed successfully!",
                            "Success",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(parent,
                    "Error removing product: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    public int getLowStockCount() {
        try (java.io.BufferedReader reader = java.nio.file.Files.newBufferedReader(java.nio.file.Paths.get("Products.txt"))) {
            return (int) reader.lines()
                    .map(line -> line.split(","))
                    .filter(data -> Integer.parseInt(data[4]) < Integer.parseInt(data[5]))
                    .count();
        } catch (Exception e) {
            return 0;
        }
    }
}