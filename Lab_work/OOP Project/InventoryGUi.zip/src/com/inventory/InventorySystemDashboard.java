package com.inventory;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.function.Supplier;

public class InventorySystemDashboard extends JFrame {
    private final InventoryManager inventoryManager;
    private final OrderManager orderManager;

    public InventorySystemDashboard() {
        inventoryManager = new InventoryManager();
        orderManager = new OrderManager();
        initializeComponents();
    }

    private void initializeComponents() {
        setTitle("Inventory Management Dashboard");
        setSize(1200, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = createMainPanel();
        add(mainPanel);
    }

    private JPanel createMainPanel() {
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBackground(Constants.DARK_BACKGROUND);

        mainPanel.add(createHeaderLabel(), BorderLayout.NORTH);
        mainPanel.add(createCardPanel(), BorderLayout.CENTER);
        mainPanel.add(createActionPanel(), BorderLayout.SOUTH);

        return mainPanel;
    }

    private JLabel createHeaderLabel() {
        JLabel label = new JLabel("Inventory Management", SwingConstants.CENTER);
        label.setFont(Constants.HEADER_FONT);
        label.setForeground(Constants.TEXT_COLOR);
        label.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        return label;
    }

    private JPanel createCardPanel() {
        JPanel cardPanel = new JPanel(new GridLayout(0, 3, 15, 15));
        cardPanel.setBackground(Constants.DARK_BACKGROUND);

        addDashboardCards(cardPanel);
        return cardPanel;
    }

    private void addDashboardCards(JPanel cardPanel) {
        addDashboardCard(cardPanel, "Total Products", () -> FileManager.getFileLineCount("Products.txt"));
        addDashboardCard(cardPanel, "Total Orders", () -> FileManager.getFileLineCount("Orders.txt"));
        addDashboardCard(cardPanel, "Low Stock Items", inventoryManager::getLowStockCount);
    }

    private void addDashboardCard(JPanel cardPanel, String title, Supplier<Integer> valueSupplier) {
        JPanel card = createCard(title, valueSupplier.get());
        cardPanel.add(card);
    }

    private JPanel createCard(String title, int value) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Constants.LIGHT_BACKGROUND);
        card.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        card.add(createCardTitleLabel(title), BorderLayout.NORTH);
        card.add(createCardValueLabel(value), BorderLayout.CENTER);

        return card;
    }

    private JLabel createCardTitleLabel(String title) {
        JLabel titleLabel = new JLabel(title, SwingConstants.CENTER);
        titleLabel.setForeground(Constants.TEXT_COLOR);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        return titleLabel;
    }

    private JLabel createCardValueLabel(int value) {
        JLabel valueLabel = new JLabel(String.valueOf(value), SwingConstants.CENTER);
        valueLabel.setForeground(Constants.TEXT_COLOR);
        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        return valueLabel;
    }

    private JPanel createActionPanel() {
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 15));
        actionPanel.setBackground(Constants.DARK_BACKGROUND);

        createActionButtons().forEach(actionPanel::add);

        return actionPanel;
    }

    private java.util.List<JButton> createActionButtons() {
        return java.util.Arrays.asList(
                createActionButton("Add Product", () -> inventoryManager.addProduct(this)),
                createActionButton("Remove Product", () -> inventoryManager.removeProduct(this)),
                createActionButton("View Products", this::viewProducts),
                createActionButton("Add Order", () -> orderManager.addOrder(this)),
                createActionButton("Remove Order", () -> orderManager.removeOrder(this)),
                createActionButton("View Orders", () -> orderManager.viewOrders(this)),
                createActionButton("Logout", this::logout)
        );
    }

    private JButton createActionButton(String text, Runnable action) {
        JButton button = new JButton(text);
        button.setBackground(Constants.LIGHT_BACKGROUND);
        button.setForeground(Color.BLACK);
        button.setFont(Constants.BUTTON_FONT);
        button.addActionListener(e -> action.run());
        return button;
    }

    private void viewProducts() {
        try {
            java.util.List<String[]> productData = FileManager.readFileData("Products.txt");

            if (productData.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No products found.",
                        "Products", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            JTable productTable = createProductTable(productData);
            JScrollPane scrollPane = new JScrollPane(productTable);
            scrollPane.setPreferredSize(new Dimension(800, 400));

            JOptionPane.showMessageDialog(this, scrollPane,
                    "Product Inventory", JOptionPane.PLAIN_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Error viewing products: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private JTable createProductTable(java.util.List<String[]> productData) {
        String[] columnNames = {"Product ID", "Name", "Category",
                "Unit Price", "Quantity", "Reorder Level", "Supplier ID"};

        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        productData.forEach(model::addRow);

        JTable productTable = new JTable(model) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        styleTable(productTable);
        return productTable;
    }

    private void styleTable(JTable table) {
        table.setBackground(Constants.LIGHT_BACKGROUND);
        table.setForeground(Constants.TEXT_COLOR);
        table.setSelectionBackground(new Color(100, 100, 100));
        table.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        table.getTableHeader().setBackground(Constants.DARK_BACKGROUND);
        table.getTableHeader().setForeground(Color.black);
    }

    private void logout() {
        dispose();
        JOptionPane.showMessageDialog(null, "Logged out successfully!",
                "Logout", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }
            new InventorySystemDashboard().setVisible(true);
        });
    }
}