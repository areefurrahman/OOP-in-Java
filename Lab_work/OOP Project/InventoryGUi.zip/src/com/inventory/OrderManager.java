package com.inventory;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;

public class OrderManager {
    public void addOrder(JFrame parent) {
        String orderDate = JOptionPane.showInputDialog(parent, "Enter Order Date (YYYY-MM-DD):");
        if (orderDate == null || orderDate.trim().isEmpty()) return;

        String status = JOptionPane.showInputDialog(parent, "Enter Order Status:");
        if (status == null || status.trim().isEmpty()) return;

        String numProductsStr = JOptionPane.showInputDialog(parent, "Enter Number of Products in Order:");
        if (numProductsStr == null || numProductsStr.trim().isEmpty()) return;

        try {
            int numProducts = Integer.parseInt(numProductsStr);
            StringBuilder orderData = new StringBuilder(orderDate + "," + status);

            for (int i = 0; i < numProducts; i++) {
                String productID = JOptionPane.showInputDialog(parent, "Enter Product ID for Product " + (i + 1) + ":");
                if (productID == null || productID.trim().isEmpty()) continue;
                orderData.append(",").append(productID);
            }

            FileManager.appendToFile("Orders.txt", orderData.toString());
            JOptionPane.showMessageDialog(parent,
                    "Order added successfully!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE
            );
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(parent,
                    "Invalid input. Please try again.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
        } catch (Exception e) {
            JOptionPane.showMessageDialog(parent,
                    "Error writing to file: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    public void removeOrder(JFrame parent) {
        try {
            ArrayList<String[]> orderData = FileManager.readFileData("Orders.txt");

            if (orderData.isEmpty()) {
                JOptionPane.showMessageDialog(parent,
                        "No orders available to remove.",
                        "Remove Order",
                        JOptionPane.WARNING_MESSAGE
                );
                return;
            }

            JPanel panel = new JPanel(new BorderLayout());
            DefaultListModel<String> listModel = new DefaultListModel<>();

            for (int i = 0; i < orderData.size(); i++) {
                String[] order = orderData.get(i);
                listModel.addElement("Order " + (i + 1) + ": " + order[0] + " - " + order[1]);
            }

            JList<String> orderList = new JList<>(listModel);
            orderList.setBackground(Constants.LIGHT_BACKGROUND);
            orderList.setForeground(Constants.TEXT_COLOR);
            orderList.setSelectionBackground(new Color(100, 100, 100));

            panel.add(new JScrollPane(orderList), BorderLayout.CENTER);

            int result = JOptionPane.showConfirmDialog(
                    parent,
                    panel,
                    "Select Order to Remove",
                    JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.PLAIN_MESSAGE
            );

            if (result == JOptionPane.OK_OPTION) {
                int selectedIndex = orderList.getSelectedIndex();
                if (selectedIndex != -1) {
                    orderData.remove(selectedIndex);
                    FileManager.writeFileData("Orders.txt", orderData);
                    JOptionPane.showMessageDialog(parent,
                            "Order removed successfully!",
                            "Success",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(parent,
                    "Error removing order: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    public void viewOrders(JFrame parent) {
        try {
            ArrayList<String[]> orderData = FileManager.readFileData("Orders.txt");

            if (orderData.isEmpty()) {
                JOptionPane.showMessageDialog(parent,
                        "No orders found.",
                        "Orders",
                        JOptionPane.INFORMATION_MESSAGE
                );
                return;
            }

            String[] columnNames = {"Order Date", "Status", "Product IDs"};
            DefaultTableModel model = new DefaultTableModel(columnNames, 0);

            for (String[] order : orderData) {
                model.addRow(order);
            }

            JTable orderTable = new JTable(model) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };

            orderTable.setBackground(Constants.LIGHT_BACKGROUND);
            orderTable.setForeground(Constants.TEXT_COLOR);
            orderTable.setSelectionBackground(new Color(100, 100, 100));
            orderTable.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            orderTable.getTableHeader().setBackground(Constants.DARK_BACKGROUND);
            orderTable.getTableHeader().setForeground(Color.black);

            JScrollPane scrollPane = new JScrollPane(orderTable);
            scrollPane.setPreferredSize(new Dimension(800, 400));

            JOptionPane.showMessageDialog(
                    parent,
                    scrollPane,
                    "Order History",
                    JOptionPane.PLAIN_MESSAGE
            );
        } catch (Exception e) {
            JOptionPane.showMessageDialog(parent,
                    "Error viewing orders: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }
}