package com.inventory;

import java.io.*;
import java.nio.file.*;
import java.util.ArrayList;

public class FileManager {
    public static ArrayList<String[]> readFileData(String filename) throws IOException {
        ArrayList<String[]> data = new ArrayList<>();
        try (BufferedReader reader = Files.newBufferedReader(Paths.get(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                data.add(line.split(","));
            }
        }
        return data;
    }

    public static void writeFileData(String filename, ArrayList<String[]> data) throws IOException {
        try (BufferedWriter writer = Files.newBufferedWriter(Paths.get(filename))) {
            for (String[] row : data) {
                writer.write(String.join(",", row));
                writer.newLine();
            }
        }
    }

    public static void appendToFile(String filename, String data) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename, true))) {
            writer.write(data);
            writer.newLine();
        }
    }

    public static int getFileLineCount(String filename) {
        try (BufferedReader reader = Files.newBufferedReader(Paths.get(filename))) {
            return (int) reader.lines().count();
        } catch (IOException e) {
            return 0;
        }
    }
}