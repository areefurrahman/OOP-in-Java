//L1f23bsse0389
//L1f23bsse0391
//L1f23bsse0395


package com.inventory;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;
import java.nio.file.*;
import java.util.ArrayList;

public class InventorySystemOneFile extends JFrame {
    private static final Color DARK_BACKGROUND = new Color(40, 40, 40);
    private static final Color LIGHT_BACKGROUND = new Color(60, 60, 60);
    private static final Color TEXT_COLOR = Color.WHITE;
    private static final Font HEADER_FONT = new Font("Segoe UI", Font.BOLD, 24);
    private static final Font BUTTON_FONT = new Font("Segoe UI", Font.BOLD, 14);

    public InventorySystemOneFile() {
        initializeFrame();
        createUI();
    }

    private void initializeFrame() {
        setTitle("EMPLOYEE DASHBOARD");
        setSize(1200, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(DARK_BACKGROUND);
    }

    private void createUI() {
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBackground(DARK_BACKGROUND);

        JLabel headerLabel = createHeaderLabel("Inventory Management Dashboard");
        mainPanel.add(headerLabel, BorderLayout.NORTH);

        JPanel cardPanel = createCardPanel();
        mainPanel.add(new JScrollPane(cardPanel), BorderLayout.CENTER);

        JPanel actionPanel = createActionPanel();
        mainPanel.add(actionPanel, BorderLayout.SOUTH);

        add(mainPanel);
    }

    private JLabel createHeaderLabel(String text) {
        JLabel label = new JLabel(text, SwingConstants.CENTER);
        label.setFont(HEADER_FONT);
        label.setForeground(TEXT_COLOR);
        label.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        return label;
    }

    private JPanel createCardPanel() {
        JPanel cardPanel = new JPanel(new GridLayout(0, 3, 15, 15));
        cardPanel.setBackground(DARK_BACKGROUND);

        cardPanel.add(createDashboardCard("Total Products", getProductCount()));
        cardPanel.add(createDashboardCard("Total Orders", getOrderCount()));
        cardPanel.add(createDashboardCard("Low Stock Items", getLowStockCount()));

        return cardPanel;
    }

    private JPanel createDashboardCard(String title, int value) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(LIGHT_BACKGROUND);
        card.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel titleLabel = new JLabel(title, SwingConstants.CENTER);
        titleLabel.setForeground(TEXT_COLOR);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));

        JLabel valueLabel = new JLabel(String.valueOf(value), SwingConstants.CENTER);
        valueLabel.setForeground(TEXT_COLOR);
        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));

        card.add(titleLabel, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);

        return card;
    }

    private JPanel createActionPanel() {
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 15));
        actionPanel.setBackground(DARK_BACKGROUND);

        String[] actions = {"Add Product", "Remove Product", "View Products",
                "Add Order", "Remove Order", "View Orders", "Logout"};

        for (String action : actions) {
            JButton button = createStyledButton(action);
            actionPanel.add(button);
            addButtonAction(button, action);
        }

        return actionPanel;
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(LIGHT_BACKGROUND);
        button.setForeground(Color.black);
        button.setFont(BUTTON_FONT);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.DARK_GRAY),
                BorderFactory.createEmptyBorder(10, 20, 10, 20)
        ));
        return button;
    }

    private void addButtonAction(JButton button, String action) {
        button.addActionListener(e -> {
            switch (action) {
                case "Add Product" -> addProduct();
                case "Remove Product" -> removeProduct();
                case "View Products" -> viewProducts();
                case "Add Order" -> addOrder();
                case "Remove Order" -> removeOrder();
                case "View Orders" -> viewOrders();
                case "Logout" -> logout();
            }
        });
    }

    private void logout() {
        dispose();
        JOptionPane.showMessageDialog(null, "Logged out successfully!",
                "Logout", JOptionPane.INFORMATION_MESSAGE);
    }

    private void addProduct() {
        ArrayList<String> productData = new ArrayList<>();
        String[] prompts = {"Product ID", "Product Name", "Category",
                "Unit Price", "Quantity", "Reorder Level", "Supplier ID"};

        for (String prompt : prompts) {
            String input = JOptionPane.showInputDialog(this, "Enter " + prompt + ":");
            if (input == null || input.trim().isEmpty()) return;
            productData.add(input);
        }

        try (BufferedWriter writer = Files.newBufferedWriter(
                Paths.get("Products.txt"), StandardOpenOption.CREATE, StandardOpenOption.APPEND)) {
            writer.write(String.join(",", productData));
            writer.newLine();
            JOptionPane.showMessageDialog(this, "Product added successfully!");
        } catch (IOException e) {
            handleError("Error adding product", e);
        }
    }

    private void handleError(String message, Exception e) {
        JOptionPane.showMessageDialog(this, message + ": " + e.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
    }

    private int getProductCount() {
        try (BufferedReader reader = Files.newBufferedReader(Paths.get("Products.txt"))) {
            return (int) reader.lines().count();
        } catch (IOException e) {
            return 0;
        }
    }

    private int getOrderCount() {
        try (BufferedReader reader = Files.newBufferedReader(Paths.get("Orders.txt"))) {
            return (int) reader.lines().count();
        } catch (IOException e) {
            return 0;
        }
    }

    private int getLowStockCount() {
        try (BufferedReader reader = Files.newBufferedReader(Paths.get("Products.txt"))) {
            return (int) reader.lines()
                    .map(line -> line.split(","))
                    .filter(data -> Integer.parseInt(data[4]) < Integer.parseInt(data[5]))
                    .count();
        } catch (IOException e) {
            return 0;
        }
    }

    private void viewProducts() {
        try {
            ArrayList<String[]> productData = readFileData("Products.txt");

            if (productData.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No products found.",
                        "Products", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            String[] columnNames = {"Product ID", "Name", "Category",
                    "Unit Price", "Quantity", "Reorder Level", "Supplier ID"};
            DefaultTableModel model = new DefaultTableModel(columnNames, 0);

            for (String[] product : productData) {
                model.addRow(product);
            }

            JTable productTable = new JTable(model) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };

            productTable.setBackground(LIGHT_BACKGROUND);
            productTable.setForeground(TEXT_COLOR);
            productTable.setSelectionBackground(new Color(100, 100, 100));
            productTable.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            productTable.getTableHeader().setBackground(DARK_BACKGROUND);
            productTable.getTableHeader().setForeground(TEXT_COLOR);

            JScrollPane scrollPane = new JScrollPane(productTable);
            scrollPane.setPreferredSize(new Dimension(800, 400));

            JOptionPane.showMessageDialog(
                    this,
                    scrollPane,
                    "Product Inventory",
                    JOptionPane.PLAIN_MESSAGE
            );
        } catch (Exception e) {
            handleError("Error viewing products", e);
        }
    }

    private void viewOrders() {
        try {
            ArrayList<String[]> orderData = readFileData("Orders.txt");

            if (orderData.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No orders found.",
                        "Orders", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            String[] columnNames = {"Order Date", "Status", "Product IDs"};
            DefaultTableModel model = new DefaultTableModel(columnNames, 0);

            for (String[] order : orderData) {
                model.addRow(order);
            }

            JTable orderTable = new JTable(model) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };

            orderTable.setBackground(LIGHT_BACKGROUND);
            orderTable.setForeground(TEXT_COLOR);
            orderTable.setSelectionBackground(new Color(100, 100, 100));
            orderTable.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            orderTable.getTableHeader().setBackground(DARK_BACKGROUND);
            orderTable.getTableHeader().setForeground(TEXT_COLOR);

            JScrollPane scrollPane = new JScrollPane(orderTable);
            scrollPane.setPreferredSize(new Dimension(800, 400));

            JOptionPane.showMessageDialog(
                    this,
                    scrollPane,
                    "Order History",
                    JOptionPane.PLAIN_MESSAGE
            );
        } catch (Exception e) {
            handleError("Error viewing orders", e);
        }
    }

    private void removeProduct() {
        try {
            ArrayList<String[]> productData = readFileData("Products.txt");

            if (productData.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No products available to remove.",
                        "Remove Product", JOptionPane.WARNING_MESSAGE);
                return;
            }

            JPanel panel = new JPanel(new BorderLayout());
            DefaultListModel<String> listModel = new DefaultListModel<>();

            for (String[] product : productData) {
                listModel.addElement(product[0] + " - " + product[1]);
            }

            JList<String> productList = new JList<>(listModel);
            productList.setBackground(LIGHT_BACKGROUND);
            productList.setForeground(TEXT_COLOR);
            productList.setSelectionBackground(new Color(100, 100, 100));

            panel.add(new JScrollPane(productList), BorderLayout.CENTER);

            int result = JOptionPane.showConfirmDialog(
                    this,
                    panel,
                    "Select Product to Remove",
                    JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.PLAIN_MESSAGE
            );

            if (result == JOptionPane.OK_OPTION) {
                String selectedProduct = productList.getSelectedValue();
                if (selectedProduct != null) {
                    String productIdToRemove = selectedProduct.split(" - ")[0];

                    productData.removeIf(product -> product[0].equals(productIdToRemove));

                    writeFileData("Products.txt", productData);

                    JOptionPane.showMessageDialog(this,
                            "Product removed successfully!",
                            "Success",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                }
            }
        } catch (Exception e) {
            handleError("Error removing product", e);
        }
    }

    private void removeOrder() {
        try {
            ArrayList<String[]> orderData = readFileData("Orders.txt");

            if (orderData.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No orders available to remove.",
                        "Remove Order", JOptionPane.WARNING_MESSAGE);
                return;
            }

            JPanel panel = new JPanel(new BorderLayout());
            DefaultListModel<String> listModel = new DefaultListModel<>();

            for (int i = 0; i < orderData.size(); i++) {
                String[] order = orderData.get(i);
                listModel.addElement("Order " + (i + 1) + ": " + order[0] + " - " + order[1]);
            }

            JList<String> orderList = new JList<>(listModel);
            orderList.setBackground(LIGHT_BACKGROUND);
            orderList.setForeground(TEXT_COLOR);
            orderList.setSelectionBackground(new Color(100, 100, 100));

            panel.add(new JScrollPane(orderList), BorderLayout.CENTER);

            int result = JOptionPane.showConfirmDialog(
                    this,
                    panel,
                    "Select Order to Remove",
                    JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.PLAIN_MESSAGE
            );

            if (result == JOptionPane.OK_OPTION) {
                int selectedIndex = orderList.getSelectedIndex();
                if (selectedIndex != -1) {
                    orderData.remove(selectedIndex);

                    writeFileData("Orders.txt", orderData);

                    JOptionPane.showMessageDialog(this,
                            "Order removed successfully!",
                            "Success",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                }
            }
        } catch (Exception e) {
            handleError("Error removing order", e);
        }
    }

    private void addOrder() {
        String orderDate = JOptionPane.showInputDialog(this, "Enter Order Date (YYYY-MM-DD):");
        if (orderDate == null || orderDate.trim().isEmpty()) return;

        String status = JOptionPane.showInputDialog(this, "Enter Order Status:");
        if (status == null || status.trim().isEmpty()) return;

        String numProductsStr = JOptionPane.showInputDialog(this, "Enter Number of Products in Order:");
        if (numProductsStr == null || numProductsStr.trim().isEmpty()) return;

        try {
            int numProducts = Integer.parseInt(numProductsStr);
            StringBuilder orderData = new StringBuilder(orderDate + "," + status);

            for (int i = 0; i < numProducts; i++) {
                String productID = JOptionPane.showInputDialog(this, "Enter Product ID for Product " + (i + 1) + ":");
                if (productID == null || productID.trim().isEmpty()) continue;
                orderData.append(",").append(productID);
            }

            try (BufferedWriter writer = new BufferedWriter(new FileWriter("Orders.txt", true))) {
                writer.write(orderData.toString());
                writer.newLine();
                JOptionPane.showMessageDialog(this, "Order added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid input. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error writing to file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private ArrayList<String[]> readFileData(String filename) throws IOException {
        ArrayList<String[]> data = new ArrayList<>();
        try (BufferedReader reader = Files.newBufferedReader(Paths.get(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                data.add(line.split(","));
            }
        }
        return data;
    }

    private void writeFileData(String filename, ArrayList<String[]> data) throws IOException {
        try (BufferedWriter writer = Files.newBufferedWriter(Paths.get(filename))) {
            for (String[] row : data) {
                writer.write(String.join(",", row));
                writer.newLine();
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }
            new InventorySystemOneFile().setVisible(true);
        });
    }
}